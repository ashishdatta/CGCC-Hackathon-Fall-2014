alert("Disclaimer: This only works in Mozilla Firefox. No, we don't know why.");
var endurance = 0;
var money = 100;
var collisions = 0;
var drop_count = 0;
var time = 0;

var badArray = new Array();
badArray[0] = new Image();
badArray[0].src = "Pictures/bad1.png";
badArray[0].value = -1;
badArray[1] = new Image(); 
badArray[1].src = "Pictures/bad2.png";
badArray[1].value = -2;
badArray[2] = new Image();
badArray[2].src = "Pictures/bad3.png";
badArray[2].value = -3;
badArray[3] = new Image();
badArray[3].src = "Pictures/bad4.png";
badArray[3].value = -1;
badArray[4] = new Image();
badArray[4].src = "Pictures/bad5.png";
badArray[4].value = -2;
badArray[5] = new Image();
badArray[5].src = "Pictures/bad6.png";
badArray[5].value = -3;
badArray[6] = new Image();
badArray[6].src = "Pictures/bad7.png";
badArray[6].value = -1;
badArray[7] = new Image();
badArray[7].src = "Pictures/bad8.png"; 
badArray[7].value = -2;

var goodArray = new Array();
goodArray[0] = new Image();
goodArray[0].src = "Pictures/fruit6.png";
goodArray[0].value = 1;
goodArray[1] = new Image(); 
goodArray[1].src = "Pictures/grains2.jpg";
goodArray[1].value = 2;
goodArray[2] = new Image();
goodArray[2].src = "Pictures/veggie3.png";
goodArray[2].value = 3;
goodArray[3] = new Image();
goodArray[3].src = "Pictures/protien4.png";
goodArray[3].value = 1;
goodArray[4] = new Image();
goodArray[4].src = "Pictures/dairy3.png";
goodArray[4].value = 2;
goodArray[5] = new Image();
goodArray[5].src = "Pictures/protien3.png";
goodArray[5].value = 3;
goodArray[6] = new Image();
goodArray[6].src = "Pictures/dairy2.png";
goodArray[6].value = 1;
goodArray[7] = new Image();
goodArray[7].src = "Pictures/Grains1.jpg"; 
goodArray[7].value = 2;

function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}
var startingmoney = money;
function drop(ev) {
  	ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
   	ev.target.appendChild(document.getElementById(data));

    if(drop_count < 6){
    	if (data == "drag1"){
			endurance += badArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag2"){
	    	endurance += badArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag3"){
	    	endurance += badArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag4"){
	    	endurance += badArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag5"){
	    	endurance += badArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag6"){
	    	endurance += badArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag7"){
	    	endurance +=goodArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag8"){
	    	endurance +=goodArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag9"){
	    	endurance +=goodArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag10"){
	    	endurance +=goodArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag11"){
	    	endurance +=goodArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	    else if (data == "drag12"){
	    	endurance += goodArray[Math.floor(Math.random() * 8)].value;
	    	document.getElementById("endurancelbl").innerHTML = endurance;
	    }
	}
	drop_count++;
}


function exit(){
	document.getElementById("stage1").style = "display:none";
	document.getElementById("stage2").style = "";
	money = money - (drop_count * 10);
	time = 100 * endurance;
	setInterval(gameloop, 1000/60);	

}

function randImage(){
	document.getElementById("drag1").src = badArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag2").src = badArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag3").src = badArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag4").src = badArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag5").src = badArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag6").src = badArray[Math.floor(Math.random() * 8)].src;

	document.getElementById("drag7").src = goodArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag8").src = goodArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag9").src = goodArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag10").src = goodArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag11").src = goodArray[Math.floor(Math.random() * 8)].src;
	document.getElementById("drag12").src = goodArray[Math.floor(Math.random() * 8)].src;
}

randImage();

	// we set the tabindex above so the canvas is the window which is focused, thus allowing keyboard inputs.
	
	// =====================================================
	// =====================================================
	// === Creating our canvas
	
	// This is what we will be drawing on.  The canvas is the overall screen, while the specific object we'll
	// draw with onto it is the context (ctx)
	var canvas = document.getElementById('myCanvas');
	var context = canvas.getContext('2d');
	var backImage= new Image();
	backImage.src = "Pictures/RunnerBackground.png";
	

	
	

	// =====================================================
	// =====================================================
	// === Constants/Variables
	
	// put any constants or variables here

	var index = -1;

	
	
	
	
	
	
	
	
	
	
	

	// =====================================================
	// =====================================================
	// === Functions
	
	// put any useful functions here


	
	
	
	
	

	
	
	
	
	// =====================================================
	// =====================================================
	// === sprites		

	// A basic sprite.
	// This implements the basic functionality of a sprite.  It has a position, speed, size, and image.
	// It also has the three main functions: Notify, Update, and Draw.  Notify is when it is told an
	// event happens (like a keypress or a mouseclick), Update is called every tick to update the game,
	// and draw is whenever we want to draw the sprite onto the screen.

	function basic_sprite(x, y, img) 
	{
			// -----------------------------------
			// Basic values.  
			this.width = 25;
			this.height = 25;
			this.x = x;
			this.y = y;
			this.dx = 0;
			this.dy = 0;

			// load the image.  Once it's done loading we can use it
			this.image = new Image();
			this.image.src = img;
			
			
			// The various functions that belong to the sprite. Notify, Update, and Draw.			
			// -----------------------------------	
			this.notify = function(event)
				{
				}
			
			
			// -----------------------------------		
			this.update = function() 
				{
					this.x += this.dx;
					this.y += this.dy;
					
					// some simple boundary checking to make sure the sprites bounce. You could do other stuff if you wanted.
					if (this.x + this.width > canvas.width)
					{
						this.x = canvas.width-this.width;
						this.dx *= -1;
					}
					else if (this.x < 0)
					{
						this.x = 0;
						this.dx *= -1;
					}
					if (this.y + this.height > canvas.height)
					{
						this.y = canvas.height - this.height;
						this.dy *= -1;
					}
					else if (this.y < 0)
					{
						this.y = 0;
						this.dy *= -1;
					}
				}
				
			// -----------------------------------
			this.draw = function()
				{
					// Commented out two lines that'd let me just draw a black box instead of the image.  Leaving for demo purposes.
					//ctx.fillStyle = "black";
					//ctx.fillRect(this.x, this.y, 25, 25);

					context.drawImage(this.image, this.x, this.y);
				}			
	};

	
	
	
	
	
	
	


	var allGroups = [];
	
	// =====================================================
	// =====================================================
	// These are our sprite groups.  We need to add each of our groups to the list of allGroups
	// so they will then start getting updated.  After that though, we can add sprites to any *ONE* 
	// of our groups and they will then start getting notified of things sent to that group 
	// (like events, update, and draw calls)
	
	
	var NPCs = [];
	var Player = [];

	// the order you add the lists is the order they are drawn in!  The first one added will be drawn first,
	// then each one after will be drawn on top of that.  
	allGroups.push(NPCs);
	allGroups.push(Player);


	
	
	
	
	
	
	






	// =====================================================
	// =====================================================
	// === initiation.  
	
	// Create all the instances of your objects in here.  Would suggest using a 'for' loop instead of straight variables, 
	// but this is just a demo.   
	
	var test2 = new basic_sprite((800/3), 300, "pictures/money.png");
	test2.dx = -4;
	NPCs.push(test2);
	var test3 = new basic_sprite((800/3)*2, 300, "pictures/money.png");
	test3.dx = -4;
	NPCs.push(test3);
	var test4 = new basic_sprite(800, 300, "pictures/money.png");
	test4.dx = -4;
	NPCs.push(test4);

	var test5 = new basic_sprite(50, 300, "pictures/runman.png");
	test5.dx = 0;
	
	Player.push(test5);
	



	// -----------------------------------------
	// Events
	// We need to manually add listeners for each event type then feed them to our events function.
	// it'll still be up to you to tell the sprites what to do with the events they hear though.
	

	// =====================================================
	// =====================================================
	// === GameLoop
	
	function gameloop()
	{
		// notify is just here for default purposes.  Maybe you want to tell the game of each tick of the gameloop
		notify(false);
		update();
		draw();
		if(spriteCollide(test5,test2)){
			kill(test2);
			create2();
		}
		if(spriteCollide(test5,test3)){
			kill(test3);
			create3();
		}
		if(spriteCollide(test5,test4)){
			kill(test4);
			create4();
		}
		
		if(time >= 0 ){
			time--;
		}else{
			exit2();
		}
	}

	// -----------------------------
	function notify(event)
	{
		if (event)
		{
			// notify all the game objects when events happen, or respond directly.
			for (i = 0; i < allGroups.length; i++)
			{
				group = allGroups[i];
				for (s = 0; s < group.length; s++)
				{
					//log(event.type);
					group[s].notify(event);
				}		
			}
		}
	}

	// -----------------------------
	function update()
	{
		// you can put gamelogic here if you like, or manage it in a super sprite object.
		
		
	
		// tell all the sprites to update themselves.  
		for (i = 0; i < allGroups.length; i++)
		{
			group = allGroups[i];
			for (s = 0; s < group.length; s++)
			{
				//log(event.type);
				group[s].update();
			}		
		}
	}			
		
	// -----------------------------
	function draw()
	{
		// clear the background
		context.clearRect(0,0, canvas.width, canvas.height);
		context.drawImage(backImage,0,0);
		context.font = '30pt Calibri';
		context.fillText('Money: ' + money,0,580);
		context.fillText('Time: ' + time,0,620);
		// now tell all the sprites to draw themselves.  if you have multiple sprite groups then you'll need to 
		// do multiple for loops
		
		for (i = 0; i < allGroups.length; i++)
		{
			group = allGroups[i];
			for (s = 0; s < group.length; s++)
			{
				//log(event.type);
				group[s].draw();
			}		
		}
	}















	// ===========================================
	// ===========================================
	// Collision detection functions
	
	// These functions will give you the ability to test whether sprites or other things have collided.  You could use pointCollide() to
	// test whether a mouseclick happened on top of a sprite, spriteCollide() to see if two sprites bumped into each other, or groupCollide()
	// to test whether an entire spriteGroup (say, one full of bullets) hits your player sprite.



	function pointCollide(sprite, x, y) {
		// tests for collision between a sprite and an x/y coordinate
		if (x > sprite.x && 
			x < sprite.x + sprite.width &&
			y > sprite.y &&
			y < sprite.y + sprite.height) {
				return true;
			}
		return false;
	}

	
	function spriteCollide(sprite1, sprite2) {
		if (sprite1.x < sprite2.x + sprite2.width  && sprite1.x + sprite1.width  > sprite2.x &&
				sprite1.y < sprite2.y + sprite2.height && sprite1.y + sprite1.height > sprite2.y) {
			// The objects are touching
			return true;
		}
		return false;
	}

	
	function groupCollide(sprite1, spriteGroup) {
		// tests for collisions between a sprite and a group of sprites
		// returns array of collided sprites
		var collidelist = new Array();

		for (var key in spriteGroup)
			{
			
			var collided = spriteCollide(sprite1, spriteGroup[key]);
			if(collided) {
				collidelist.push(sprite1);
			}
		}
		return collidelist;
	}


	
	// ===========================================
	// ===========================================
	// === remove from group(s) function
	
	var index = -1;
	function kill(sprite)
	{
		// we cycle through all the groups and splice closed the group based on if we find an instance of our sprite in it.
		money += 10;
		collisions++;
		for (i = 0; i < allGroups.length; i++)
		{
			group = allGroups[i];
			index = -1;
			index = group.indexOf(sprite);
			if (index > -1)
			{
				group.splice(index, 1);
			}
		}
	}

	function create2(){
			this.test2 = new basic_sprite(800,300,"Pictures/money.png");
			this.test2.dx = -4;
			NPCs.push(this.test2);
	}
	function create3(){
			this.test3 = new basic_sprite(800,300,"Pictures/money.png");
			this.test3.dx = -4;
			NPCs.push(this.test3);
	}
	function create4(){
			this.test4 = new basic_sprite(800,300,"Pictures/money.png");
			this.test4.dx = -4;
			NPCs.push(this.test4);
	}

	// ===========================================
	// ===========================================
	// === console log() command.  
	
	// A nifty shortcut that lets you just put "log(some_variable_or_text);" in your code and get feedback 
	// in the javascript console in the browser. 
	
	function log(msg) 
	{
		console.log(msg);
	}


	function exit2(){
			document.getElementById("stage2").style = "display:none";
			document.getElementById("stage1").style = "";
			endurance = 0;
			money = (collisions * 10) + money;
			collisons = 0;
			clearInterval(gameloop);
			location.reload();
			updateMoney();
			randImag();	
			

	}
	// ===========================================
	// ===========================================
	// === Starting the gameloop!
	