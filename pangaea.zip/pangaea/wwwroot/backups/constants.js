/* //------------
//System Values
//------------
var STAGE_WIDTH = 600,
     STAGE_HEIGHT = 400,
    TIME_PER_FRAME = 33, //this equates to 30 fps
    GAME_FONTS = "bold 20px Lato";

var COUNTER_X = 100,
     COUNTER_Y = 100; */