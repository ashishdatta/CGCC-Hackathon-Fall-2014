<!DOCTYPE html>
<html lang="en">
     <head>
          <meta charset="UTF-8">

          <link rel="stylesheet" href="css/main.css">
          <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic'>

          <link rel="stylesheet" href="//i.icomoon.io/public/temp/329a58dc9c/UntitledProject1/style.css">

          <title>Froot | Pangaea</title>
     </head>
     <body class="bg-cabin">

          <button onClick="window.location.href='reviews'" style="float: left; margin-left: 20px;"><span class="icon-arrow-left"></span> Reviews</button>
          <button onClick="window.location.href='about'" style="float: right; margin-right: 20px;">About Us <span class="icon-arrow-right"></span></button>

          <div class="game-header">
               <h1><a href=""><span class="icon-leaf"></span> Froot</a></h1>
          </div>

          <canvas id="canvas" width=900 height=506></canvas>

          <div class="game-footer">
               <h4>&#169 Copyright 2014 <a href="about.php">Pangaea</a></h4>
          </div>

          <!-- <script type="text/javascript">
               var curX = 0;
               var canvas = document.getElementById("canvas");
               var ctx = canvas.getContext("2d");
               var background = new Image();
               background.src = "img/bg.png";
               var index = -1;

               var score = 0;

               function basic_sprite(type, img)
               {
                         this.width = 75;
                         this.height = 75;
                         this.type = type;

                         this.image = new Image();
                         this.image.src = img;

                         this.notify = function(event)
                              {
                                   if (mclicked == true && pointCollide(this, event.offsetX, event.offsetY)) {
                                        kill(this);
                                        score+=50;

                                   }

                              }

                         this.update = function()
                              {
                                   this.x += this.dx;
                                   this.y += this.dy;
                                   this.dy += 0.05;

                                   if (this.y > canvas.height)
                                   {
                                   kill(this);
                                   }
                              }

                         this.draw = function()
                              {
                                   ctx.drawImage(this.image, this.x, this.y);
                              }
                         this.reset = function()
                              {
                                   this.x = Math.floor((Math.random()* 850) + 1);
                                   this.y = 505;
                                   this.dx = (Math.random()-0.5)*2.5;
                                   this.dy = -((Math.random()*4.3)+3.5);
                              }
               }; //end basic sprite

               var Diff = 5;
               var mclicked = false;

               var Fruits = [];
               var Vege = [];
               var Dairy = [];
               var Grain = [];
               var Meat = [];
               var Junk = [];
               var allGroups = [Fruits, Dairy, Vege, Grain, Meat, Junk];
               var thrown = [];


               var waveCount = Math.floor((Math.random() * 4) + Diff);

               var apple = new basic_sprite(0,"img/apple.png");
               var watermelon = new basic_sprite(0,"img/watermelon.png");
               var banana = new basic_sprite(0,"img/banana.png");

               var broc = new basic_sprite(1,"img/broc.png");
               var cabbage = new basic_sprite(1,"img/cabbage.png");
               var pumpkin = new basic_sprite(1,"img/pumpkin.png");

               var yogurt = new basic_sprite(2,"img/yogurt.png");
               var cheese = new basic_sprite(2,"img/cheese.png");
               var milk = new basic_sprite(2,"img/milk.png");

               var bread = new basic_sprite(3,"img/bread.png");
               var bagel = new basic_sprite(3,"img/bagel.png");
               var muffin = new basic_sprite(3,"img/muffin.png");

               var steak = new basic_sprite(4,"img/steak.png");
               var chicken = new basic_sprite(4,"img/chicken.png");
               var salmon = new basic_sprite(4,"img/salmon.png");

               Fruits.push(apple, watermelon, banana);
               Vege.push(broc, cabbage, pumpkin);
               Dairy.push(yogurt, cheese, milk);
               Grain.push(bread, bagel, muffin);
               Meat.push(steak, chicken, salmon);

               for (var i=0; i < allGroups.length; i++) {
                    for (var j=0; j<allGroups[i].length; j++) {
                         allGroups[i][j].reset();
                    }
               }

               if(thrown.length < 1) {
                    for (var i = 0; i < waveCount; i++) {
                         thrown.push(allGroups[Math.floor((Math.random() * 5))][Math.floor((Math.random() * 3))]);
                    }
               }

               canvas.addEventListener("mousedown", notify); //
               canvas.addEventListener("mouseup", notify);  //change to other handlers
               canvas.addEventListener("mousemove", notify); //


               // mousedown handler
               //  check all food objects
               //  if on one, set 'dragging' flag and reset liit
               // mousemove handler
               //  check dragging flag
               //  if true, check for collisions
               // mouseup handler


               function gameloop()
               {
                    notify(false);
                    update();
                    draw();

               }

               function notify(event)
               {
                    if (event)
                    {
                         // notify all the game objects when events happen, or respond directly.

                         if (event.type == "mousedown") {
                              mclicked = true;
                         }

                         if (event.type =="mouseup") {
                              mclicked = false;
                         }


                              for (s = 0; s < thrown.length; s++)
                              {

                                   thrown[s].notify(event);
                              }

                    }
               }



               function update()
               {
                    if(thrown.length < 1) {
                         waveCount = Math.floor((Math.random() * 4) + Diff);
                         wx = 0;
                         wy = 0;
                         for (var i = 0; i < waveCount; i++) {
                              wx = Math.floor((Math.random() * 5));
                              wy = Math.floor((Math.random() * 3));
                              allGroups[wx][wy].reset();
                              thrown.push(allGroups[wx][wy]);
                         }
                         //console.log(thrown);

                    }



                    for (i = 0; i < thrown.length; i++)
                    {
                         thrown[i].update();
                    }
               }

               function draw()
               {
                    ctx.clearRect(0,0, canvas.width, canvas.height);
                    ctx.drawImage(background,0,0);
                    ctx.textAlign="center";
                    ctx.font = "35pt Lato";
                    ctx.fillStyle = "#fff";
                    ctx.fillText(score, 450,72);

                    for (i = 0; i < thrown.length; i++)
                    {
                         thrown[i].draw();
                    }
               }

               // ===========================================
               // ===========================================
               // Collision detection functions

               // These functions will give you the ability to test whether sprites or other things have collided.  You could use pointCollide() to
               // test whether a mouseclick happened on top of a sprite, spriteCollide() to see if two sprites bumped into each other, or groupCollide()
               // to test whether an entire spriteGroup (say, one full of bullets) hits your player sprite.

               function pointCollide(sprite, x, y) {
                    // tests for collision between a sprite and an x/y coordinate
                    if (x > sprite.x &&
                         x < sprite.x + sprite.width &&
                         y > sprite.y &&
                         y < sprite.y + sprite.height) {
                              return true;
                         }
                    return false;
               }

               function spriteCollide(sprite1, sprite2) {
                    if (sprite1.x < sprite2.x + sprite2.width  && sprite1.x + sprite1.width  > sprite2.x &&
                              sprite1.y < sprite2.y + sprite2.height && sprite1.y + sprite1.height > sprite2.y) {
                         // The objects are touching
                         return true;
                    }
                    return false;
               }

               function groupCollide(sprite1, spriteGroup) {
                    // tests for collisions between a sprite and a group of sprites
                    // returns array of collided sprites
                    var collidelist = new Array();

                    for (var key in spriteGroup)
                         {

                         var collided = spriteCollide(sprite1, spriteGroup[key]);
                         if(collided) {
                              collidelist.push(sprite1);
                         }
                    }
                    return collidelist;
               }

               var index = -1;
               function kill(sprite)
               {
                    for (i = 0; i < thrown.length; i++)
                    {

                         index = -1;
                         index = thrown.indexOf(sprite);
                         if (index > -1)
                         {
                              thrown.splice(index, 1);
                         }
                    }
               }

               // ===========================================
               // ===========================================
               // === console log() command.

               // A nifty shortcut that lets you just put "log(some_variable_or_text);" in your code and get feedback
               // in the javascript console in the browser.

               function log(msg)
               {
                    console.log(msg);
               }

               setInterval(gameloop, 1000/60);
          </script> -->

          <script>
               var snd = new Audio("audio/proctor.mp3");
               snd.volume = 0.33;
               snd.loop = true;
               snd.play();
               var slice1 = new Audio("audio/slice.mp3");

               var curX = 0;
               var canvas = document.getElementById("canvas");
               var ctx = canvas.getContext("2d");
               var background = new Image();
               background.src = "img/bg.png";
               var index = -1;
               var dtime;

               var score = 0;
               var scoreInc = 50;


               var fruit_count = 0;
               var vege_count = 0;
               var dairy_count = 0;
               var grain_count = 0;
               var meat_count = 0;

               function fruit_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/F_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/F_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/F_2.png";
                    this.images.push(tempimg);

                    this.x = 713; // fix
                    this.y = 39; // fix
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (fruit_count >= 2)
                              this.img_select = 2;
                         else
                              this.img_select = fruit_count;
                    }
               }

               function vege_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/V_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/V_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/V_2.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/V_3.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (vege_count >= 3)
                              this.img_select = 3;
                         else
                              this.img_select = vege_count;
                    }
               }

               function dairy_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/D_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/D_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/D_2.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/D_3.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (dairy_count >= 3)
                              this.img_select = 3;
                         else
                              this.img_select = dairy_count;
                    }
               }

               function grain_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/G_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_2.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_3.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_4.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_5.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_6.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (grain_count >= 6)
                              this.img_select = 6;
                         else
                              this.img_select = grain_count;
                    }
               }

               function meat_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/P_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/P_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/P_2.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (meat_count >= 2)
                              this.img_select = 2;
                         else
                              this.img_select = meat_count;
                    }
               }



               function basic_sprite(type, img)
               {
                         this.width = 75;
                         this.height = 75;
                         this.type = type;

                         this.image = new Image();
                         this.image.src = img;

                         this.notify = function(event)
                              {
                                   if (mclicked == true && pointCollide(this, event.offsetX, event.offsetY)) {
                                        slice1.play();
                                        kill(this);
                                        score+=scoreInc;
                                        if(this.type==0)
                                             fruit_count++;
                                        if(this.type==1)
                                             vege_count++;
                                        if(this.type==2)
                                             dairy_count++;
                                        if(this.type==3)
                                             grain_count++;
                                        if(this.type==4)
                                             meat_count++;
                                   }

                              }

                         this.update = function()
                              {
                                   this.x += this.dx;
                                   this.y += this.dy;
                                   this.dy += 0.05;

                                   if (this.y > canvas.height)
                                   {
                                   kill(this);
                                   }
                              }

                         this.draw = function()
                              {
                                   ctx.drawImage(this.image, this.x, this.y);
                              }
                         this.reset = function()
                              {
                                   this.x = Math.floor((Math.random()* 850) + 1);
                                   this.y = 505;
                                   this.dx = (Math.random()-0.5)*2.5;
                                   this.dy = -((Math.random()*4.3)+3.5);
                              }
               }; //end basic sprite


               function bad_sprite(img, width, height)
               {
                    this.width = width;
                    this.height = height;

                    this.image = new Image();
                    this.image.src = img;

                    this.notify = function(event) {
                         if (mclicked == true && pointCollide(this, event.offsetX, event.offsetY)) {
                              kill(this);
                              score -=1000;
                              if (score < 0)
                                   score = 0;
                         }
                    }

                    this.draw = function() {
                    ctx.drawImage(this.image, this.x, this.y);
                    }

                    this.update = function()
                              {
                                   this.x += this.dx;
                                   this.y += this.dy;
                                   this.dy += 0.05;

                                   if (this.y > canvas.height)
                                   {
                                   kill(this);
                                   }
                              }


                    this.reset = function() {
                    this.x = Math.floor((Math.random() * 850) + 1);
                    this.y = 505;
                    this.dx = (Math.random()-0.5)*2.5;
                    this.dy = -((Math.random()*4.3)+3.5);
                    }

               }





               var diff = 5;
               var mclicked = false;

               var Fruits = [];
               var Vege = [];
               var Dairy = [];
               var Grain = [];
               var Meat = [];
               var Junk = [];
               var allGroups = [Fruits, Vege, Dairy, Grain, Meat, Junk];
               var thrown = [];


               var waveCount = Math.floor((Math.random() * 4) + diff);

               var apple = new basic_sprite(0,"img/apple.png");
               var watermelon = new basic_sprite(0,"img/watermelon.png");
               var banana = new basic_sprite(0,"img/banana.png");

               var broc = new basic_sprite(1,"img/broc.png");
               var cabbage = new basic_sprite(1,"img/cabbage.png");
               var pumpkin = new basic_sprite(1,"img/pumpkin.png");

               var yogurt = new basic_sprite(2,"img/yogurt.png");
               var cheese = new basic_sprite(2,"img/cheese.png");
               var milk = new basic_sprite(2,"img/milk.png");

               var bread = new basic_sprite(3,"img/bread.png");
               var bagel = new basic_sprite(3,"img/bagel.png");
               var muffin = new basic_sprite(3,"img/muffin.png");

               var steak = new basic_sprite(4,"img/steak.png");
               var chicken = new basic_sprite(4,"img/chicken.png");
               var salmon = new basic_sprite(4,"img/salmon.png");

               var burger = new bad_sprite ("img/burger.png", 150, 117);
               var icecream = new bad_sprite("img/icecream.png", 63,150);
               var fries = new bad_sprite("img/fries.png", 111, 150);

               var fruitScoreBoard = new fruit_score();
               var vegeScoreBoard = new vege_score();
               var dairyScoreBoard = new dairy_score();
               var grainScoreBoard = new grain_score();
               var meatScoreBoard = new meat_score();

               Fruits.push(apple, watermelon, banana);
               Vege.push(broc, cabbage, pumpkin);
               Dairy.push(yogurt, cheese, milk);
               Grain.push(bread, bagel, muffin);
               Meat.push(steak, chicken, salmon);
               Junk.push(burger, icecream, fries);

               for (var i=0; i < allGroups.length; i++) {
                    for (var j=0; j<allGroups[i].length; j++) {
                         allGroups[i][j].reset();
                    }
               }

               if(thrown.length < 1) {
                    for (var i = 0; i < waveCount; i++) {
                         thrown.push(allGroups[Math.floor((Math.random() * 6))][Math.floor((Math.random() * 3))]);
                    }
               }

               canvas.addEventListener("mousedown", notify); //
               canvas.addEventListener("mouseup", notify);  //change to other handlers
               canvas.addEventListener("mousemove", notify); //

               function gameloop()
               {
                    notify(false);
                    update();
                    draw();

               }

               function notify(event)
               {
                    if (event)
                    {
                         // notify all the game objects when events happen, or respond directly.

                         if (event.type == "mousedown") {
                              mclicked = true;
                              dtime = 60;
                         }

                         if (event.type =="mouseup") {
                              mclicked = false;
                         }


                              for (s = 0; s < thrown.length; s++)
                              {

                                   thrown[s].notify(event);
                              }

                    }
               }



               function update()
               {

                    fruitScoreBoard.update();
                    vegeScoreBoard.update();
                    dairyScoreBoard.update();
                    grainScoreBoard.update();
                    meatScoreBoard.update();
                    dtime--;
                    if(dtime < 1) {
                         mclicked = false;
                    }

                    if(thrown.length < 1) {
                         waveCount = Math.floor((Math.random() * 4) + diff);
                         wx = 0;
                         wy = 0;
                         for (var i = 0; i < waveCount; i++) {
                              wx = Math.floor((Math.random() * 6));
                              wy = Math.floor((Math.random() * 3));
                              allGroups[wx][wy].reset();
                              thrown.push(allGroups[wx][wy]);
                         }
                         //console.log(thrown);

                    }

                    for (i = 0; i < thrown.length; i++)
                    {
                         thrown[i].update();
                    }

                    if ((fruit_count >= 2) && (vege_count >= 3) && (dairy_count >= 3) && (grain_count >= 6) && (meat_count >= 2)) {
                         diff+=2;
                         scoreInc+=50;
                         fruit_count = 0;
                         vege_count = 0;
                         dairy_count = 0;
                         grain_count = 0;
                         meat_count = 0;

                    }


               }

               function draw()
               {
                    ctx.clearRect(0,0, canvas.width, canvas.height);
                    ctx.drawImage(background,0,0);
                    ctx.textAlign="center";
                    ctx.font = "35pt Lato";
                    ctx.fillStyle = "#fff";
                    ctx.fillText(score, 450,72);

                    fruitScoreBoard.draw();
                    vegeScoreBoard.draw();
                    dairyScoreBoard.draw();
                    grainScoreBoard.draw();
                    meatScoreBoard.draw();

                    for (i = 0; i < thrown.length; i++)
                    {
                         thrown[i].draw();
                    }
               }

               function pointCollide(sprite, x, y) {
                    if (x > sprite.x &&
                         x < sprite.x + sprite.width &&
                         y > sprite.y &&
                         y < sprite.y + sprite.height) {
                              return true;
                         }
                    return false;
               }


               var index = -1;
               function kill(sprite)
               {
                    for (i = 0; i < thrown.length; i++)
                    {

                         index = -1;
                         index = thrown.indexOf(sprite);
                         if (index > -1)
                         {
                              thrown.splice(index, 1);
                         }
                    }
               }

               // ===========================================
               // ===========================================
               // === console log() command.

               // A nifty shortcut that lets you just put "log(some_variable_or_text);" in your code and get feedback
               // in the javascript console in the browser.

               function log(msg)
               {
                    console.log(msg);
               }

               setInterval(gameloop, 1000/60);

          </script>

          <!-- <script>
               var curX = 0;
               var canvas = document.getElementById("canvas");
               var ctx = canvas.getContext("2d");
               var background = new Image();
               background.src = "img/bg.png";
               var index = -1;

               var score = 0;
               var scoreInc = 50;


               var fruit_count = 0;
               var vege_count = 0;
               var dairy_count = 0;
               var grain_count = 0;
               var meat_count = 0;

               function fruit_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/F_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/F_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/F_2.png";
                    this.images.push(tempimg);

                    this.x = 713; // fix
                    this.y = 39; // fix
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (fruit_count >= 2)
                              this.img_select = 2;
                         else
                              this.img_select = fruit_count;
                    }
               }

               function vege_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/V_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/V_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/V_2.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/V_3.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (vege_count >= 3)
                              this.img_select = 3;
                         else
                              this.img_select = vege_count;
                    }
               }

               function dairy_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/D_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/D_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/D_2.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/D_3.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (dairy_count >= 3)
                              this.img_select = 3;
                         else
                              this.img_select = dairy_count;
                    }
               }

               function grain_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/G_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_2.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_3.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_4.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_5.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/G_6.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (grain_count >= 6)
                              this.img_select = 6;
                         else
                              this.img_select = grain_count;
                    }
               }

               function meat_score() {
                    this.images = [];

                    var tempimg = new Image();
                    tempimg.src = "img/P_0.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/P_1.png";
                    this.images.push(tempimg);

                    tempimg = new Image();
                    tempimg.src = "img/P_2.png";
                    this.images.push(tempimg);

                    this.x = 713;
                    this.y = 39;
                    this.img_select = 0;

                    this.draw = function() {
                         ctx.drawImage(this.images[this.img_select], this.x, this.y);
                    }

                    this.update = function() {
                         if (meat_count >= 2)
                              this.img_select = 2;
                         else
                              this.img_select = meat_count;
                    }
               }



               function basic_sprite(type, img)
               {
                         this.width = 75;
                         this.height = 75;
                         this.type = type;

                         this.image = new Image();
                         this.image.src = img;

                         this.notify = function(event)
                              {
                                   if (mclicked == true && pointCollide(this, event.offsetX, event.offsetY)) {
                                        kill(this);
                                        score+=scoreInc;
                                        if(this.type==0)
                                             fruit_count++;
                                        if(this.type==1)
                                             vege_count++;
                                        if(this.type==2)
                                             dairy_count++;
                                        if(this.type==3)
                                             grain_count++;
                                        if(this.type==4)
                                             meat_count++;
                                   }

                              }

                         this.update = function()
                              {
                                   this.x += this.dx;
                                   this.y += this.dy;
                                   this.dy += 0.05;

                                   if (this.y > canvas.height)
                                   {
                                   kill(this);
                                   }
                              }

                         this.draw = function()
                              {
                                   ctx.drawImage(this.image, this.x, this.y);
                              }
                         this.reset = function()
                              {
                                   this.x = Math.floor((Math.random()* 850) + 1);
                                   this.y = 505;
                                   this.dx = (Math.random()-0.5)*2.5;
                                   this.dy = -((Math.random()*4.3)+3.5);
                              }
               }; //end basic sprite


               function bad_sprite(img, width, height)
               {
                    this.width = width;
                    this.height = height;

                    this.image = new Image();
                    this.image.src = img;

                    this.notify = function(event) {
                         if (mclicked == true && pointCollide(this, event.offsetX, event.offsetY)) {
                              kill(this);
                              score -=100;
                         }
                    }

                    this.draw = function() {
                    ctx.drawImage(this.image, this.x, this.y);
                    }

                    this.update = function()
                              {
                                   this.x += this.dx;
                                   this.y += this.dy;
                                   this.dy += 0.05;

                                   if (this.y > canvas.height)
                                   {
                                   kill(this);
                                   }
                              }


                    this.reset = function() {
                    this.x = Math.floor((Math.random() * 850) + 1);
                    this.y = 505;
                    this.dx = (Math.random()-0.5)*2.5;
                    this.dy = -((Math.random()*4.3)+3.5);
                    }

               }





               var diff = 5;
               var mclicked = false;

               var Fruits = [];
               var Vege = [];
               var Dairy = [];
               var Grain = [];
               var Meat = [];
               var Junk = [];
               var allGroups = [Fruits, Vege, Dairy, Grain, Meat, Junk];
               var thrown = [];


               var waveCount = Math.floor((Math.random() * 4) + diff);

               var apple = new basic_sprite(0,"img/apple.png");
               var watermelon = new basic_sprite(0,"img/watermelon.png");
               var banana = new basic_sprite(0,"img/banana.png");

               var broc = new basic_sprite(1,"img/broc.png");
               var cabbage = new basic_sprite(1,"img/cabbage.png");
               var pumpkin = new basic_sprite(1,"img/pumpkin.png");

               var yogurt = new basic_sprite(2,"img/yogurt.png");
               var cheese = new basic_sprite(2,"img/cheese.png");
               var milk = new basic_sprite(2,"img/milk.png");

               var bread = new basic_sprite(3,"img/bread.png");
               var bagel = new basic_sprite(3,"img/bagel.png");
               var muffin = new basic_sprite(3,"img/muffin.png");

               var steak = new basic_sprite(4,"img/steak.png");
               var chicken = new basic_sprite(4,"img/chicken.png");
               var salmon = new basic_sprite(4,"img/salmon.png");

               var burger = new bad_sprite ("img/burger.png", 150, 117);
               var icecream = new bad_sprite("img/icecream.png", 63,150);
               var fries = new bad_sprite("img/fries.png", 111, 150);

               var fruitScoreBoard = new fruit_score();
               var vegeScoreBoard = new vege_score();
               var dairyScoreBoard = new dairy_score();
               var grainScoreBoard = new grain_score();
               var meatScoreBoard = new meat_score();

               Fruits.push(apple, watermelon, banana);
               Vege.push(broc, cabbage, pumpkin);
               Dairy.push(yogurt, cheese, milk);
               Grain.push(bread, bagel, muffin);
               Meat.push(steak, chicken, salmon);
               Junk.push(burger, icecream, fries);

               for (var i=0; i < allGroups.length; i++) {
                    for (var j=0; j<allGroups[i].length; j++) {
                         allGroups[i][j].reset();
                    }
               }

               if(thrown.length < 1) {
                    for (var i = 0; i < waveCount; i++) {
                         thrown.push(allGroups[Math.floor((Math.random() * 6))][Math.floor((Math.random() * 3))]);
                    }
               }

               canvas.addEventListener("mousedown", notify); //
               canvas.addEventListener("mouseup", notify);  //change to other handlers
               canvas.addEventListener("mousemove", notify); //

               function gameloop()
               {
                    notify(false);
                    update();
                    draw();

               }

               function notify(event)
               {
                    if (event)
                    {
                         // notify all the game objects when events happen, or respond directly.

                         if (event.type == "mousedown") {
                              mclicked = true;
                         }

                         if (event.type =="mouseup") {
                              mclicked = false;
                         }


                              for (s = 0; s < thrown.length; s++)
                              {

                                   thrown[s].notify(event);
                              }

                    }
               }



               function update()
               {

                    fruitScoreBoard.update();
                    vegeScoreBoard.update();
                    dairyScoreBoard.update();
                    grainScoreBoard.update();
                    meatScoreBoard.update();

                    if(thrown.length < 1) {
                         waveCount = Math.floor((Math.random() * 4) + diff);
                         wx = 0;
                         wy = 0;
                         for (var i = 0; i < waveCount; i++) {
                              wx = Math.floor((Math.random() * 6));
                              wy = Math.floor((Math.random() * 3));
                              allGroups[wx][wy].reset();
                              thrown.push(allGroups[wx][wy]);
                         }
                         //console.log(thrown);

                    }

                    for (i = 0; i < thrown.length; i++)
                    {
                         thrown[i].update();
                    }

                    if ((fruit_count >= 2) && (vege_count >= 3) && (dairy_count >= 3) && (grain_count >= 6) && (meat_count >= 2)) {
                         diff+=2;
                         scoreInc+=50;
                         fruit_count = 0;
                         vege_count = 0;
                         dairy_count = 0;
                         grain_count = 0;
                         meat_count = 0;

                    }


               }

               function draw()
               {
                    ctx.clearRect(0,0, canvas.width, canvas.height);
                    ctx.drawImage(background,0,0);
                    ctx.textAlign="center";
                    ctx.font = "35pt Lato";
                    ctx.fillStyle = "#fff";
                    ctx.fillText(score, 450,72);

                    fruitScoreBoard.draw();
                    vegeScoreBoard.draw();
                    dairyScoreBoard.draw();
                    grainScoreBoard.draw();
                    meatScoreBoard.draw();

                    for (i = 0; i < thrown.length; i++)
                    {
                         thrown[i].draw();
                    }
               }

               function pointCollide(sprite, x, y) {
                    if (x > sprite.x &&
                         x < sprite.x + sprite.width &&
                         y > sprite.y &&
                         y < sprite.y + sprite.height) {
                              return true;
                         }
                    return false;
               }


               var index = -1;
               function kill(sprite)
               {
                    for (i = 0; i < thrown.length; i++)
                    {

                         index = -1;
                         index = thrown.indexOf(sprite);
                         if (index > -1)
                         {
                              thrown.splice(index, 1);
                         }
                    }
               }

               // ===========================================
               // ===========================================
               // === console log() command.

               // A nifty shortcut that lets you just put "log(some_variable_or_text);" in your code and get feedback
               // in the javascript console in the browser.

               function log(msg)
               {
                    console.log(msg);
               }

               setInterval(gameloop, 1000/60);

          </script>


          <!-- <script>
               // we set up our canvas
               var can = document.getElementById("canvas");
               // context is what draws to the canvas
               var ctx = can.getContext("2d");

               // create image
               var icecream = new Image();

               icecream.onload = loaded;
               icecream.src = "img/icecream.png";

               // create image
               var orange = new Image();

               orange.onload = loaded;
               orange.src = "img/orange-2.png";

               var numImages = 1;
               var numLoaded = 0;

               function loaded()
               {
                    numLoaded++;
                    if(numLoaded >= numImages)
                    {

                    }
               }

               ctx.font = "15pt Lato";
               // ctx.fillStyle = "#FFF";

               can.addEventListener("click", clicked); // when clicked, call the function 'clicked'

               var stamps = new Array();
               var maxStamps = 10;

               function CoordStamp(a, b)
               {
                    this.x = a;
                    this.y = b;
                    this.v = 0;
               }

               // define function 'clicked'
               function clicked(e)
               {
                    var x = e.offsetX - 70;
                    var y = e.offsetY - 42;

                    // create new object
                    var newstamp = new CoordStamp(x, y);

                    // push stamps array to object
                    stamps.push(newstamp);

                    if(stamps.length >= maxStamps)
                    {
                         stamps.splice(0, 1);
                    }
               }

               function game()
               {
                    for(var i = 0; i < stamps.length; i++)
                    {
                         stamps[i].y += stamps[i].v++;
                    }
               }

               function draw()
               {
                    ctx.clearRect(0,0, can.width, can.height);
                    for(var i = 0; i < stamps.length; i++)
                    {
                         ctx.fillText("Ice Cream", stamps[i].x, stamps[i].y - 20); // msg, x, y
                         ctx.drawImage(icecream, stamps[i].x, stamps[i].y, 100, 100); // img
                         ctx.fillText("Orange", stamps[i].x + 100, stamps[i].y);
                         ctx.drawImage(orange, stamps[i].x + 100, stamps[i].y, 100, 100);
                    }
               }

               setInterval(game, 1000/30);
               setInterval(draw, 1000/30);

               /*
               context.font = "30pt Lato";
               context.fillStyle = "#0071c5";
               context.strokeStyle = "rgba(0,0,0, 0.2)";

               context.fillText("Hello world", 50, 100); // msg, location x,y

               context.fillRect(10, 10, 100, 100); // x,y,w,h
               context.strokeRect(10, 10, 100, 100);
               */
          </script> -->
     </body>
</html>