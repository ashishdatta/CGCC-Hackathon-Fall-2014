/* //------------
//System Vars
//------------
var stage = document.getElementById("canvas");
stage.width = STAGE_WIDTH;
stage.height = STAGE_HEIGHT;
var ctx = stage.getContext("2d");
ctx.fillStyle = "black";
ctx.font = GAME_FONTS;

var gameloop = setInterval(update, TIME_PER_FRAME);
var counter = 0;

//------------
//Game Loop
//------------
function update()
{
     counter++;

     //Clear Canvas
     ctx.fillStyle = "#AAA";
     ctx.fillRect(0, 0, stage.width, stage.height);

     //Draw Timer
     ctx.fillStyle = "#000";
     ctx.fillText(counter, COUNTER_X, COUNTER_Y);
} */

