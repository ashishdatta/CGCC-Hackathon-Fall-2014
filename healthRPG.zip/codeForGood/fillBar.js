// position, size, level, images
function FillBar(x, y, w, h, l, imgFill, imgBorder)
{
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	
	this.level = l;
	
	this.fillY = this.y + this.h - 2;
	
	this.fillImage = imgFill;
	this.borderImage = imgBorder;
	
	this.draw = function(context)
	{
		context.drawImage(this.borderImage, this.x, this.y, this.w, this.h);
		context.drawImage(this.fillImage, this.x + 9, this.y - 7 + this.h * (1 - this.level), this.w - 18, this.h * this.level);
	};
};
