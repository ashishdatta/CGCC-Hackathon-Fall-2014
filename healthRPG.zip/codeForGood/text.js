// position, size, string
function Text(x, y, w, h, str)
{
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.string = str;
	
	this.draw = function(context)
	{
		context.font = "20pt Calibri";
		context.textBaseline = "middle";
		context.textAlign = "center";
		context.fillStyle = "#DE9800";
		context.fillText(this.string, this.x + this.w / 2, this.y + this.h / 2);
	};
};
