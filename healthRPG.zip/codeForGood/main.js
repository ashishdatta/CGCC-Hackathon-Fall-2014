var canvas;
var context;
var state;
var stateChange = true;

var character;
var characterImageFile = "dude.png";

var characterExp = parseInt(localStorage.getItem("exp")) || 0;
var characterLevel = parseInt(localStorage.getItem("level")) || 1;

var expFillBar;

var day = true;

var levelText;

function State(initFunc)
{
	this.init = initFunc;
	this.objects = [];
};

var mainState = new State(function()
{
	// clear array of objects so we don't duplicate
	this.objects = [];
	// need text to go here of character name
	var name = new Text(10, 10, 300, 40, "Nunchuk Pirate");
	
	// avatar
	character = new Character(10, 50, 300, 280, "Character", "Hello!", getImage(characterImageFile));
	character.exp = characterExp;
	character.level = characterLevel;
	
	levelText = new Text(10, 50, 80, 40, "level: " + character.level);
	
	expFillBar = new FillBar(canvas.width - 80, 60, 50, 260, character.exp / character.expToLevel, getImage("experience.png"), getImage("border.png"));
	
	var eatButton = new Button(10, 330, 300, 40, "Just Ate", getImage("button.png"), function()
	{
		state = eatState;
		stateChange = true;
	});
	
	var activitiesButton = new Button(10, 380, 300, 40, "Activities", getImage("button.png"), function()
	{
		state = activitiesState;
		stateChange = true;
	});
	
	var unlockablesButton = new Button(10, 430, 300, 40, "Unlockables", getImage("button.png"), function()
	{
		state = unlocksState;
		stateChange = true;
	});
	
	this.objects.push(name);
	
	this.objects.push(character);
	
	this.objects.push(levelText);
	
	this.objects.push(expFillBar);
	
	this.objects.push(eatButton);
	this.objects.push(activitiesButton);
	this.objects.push(unlockablesButton);
});

var eatState = new State(function()
{
	// clear array of objects so we don't duplicate
	this.objects = [];
	
	var checkTitle = new Text(10, 10, 300, 40, "Food Groups");
	
	// Fruits
	var fruitCheckBox = new CheckBox(10, 60, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 1;
		}
	});
	
	var fruitCheckText = new Text(80, 60, 230, 60, "Fruit");
	
	// Veggies
	var veggiesCheckBox = new CheckBox(10, 130, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 1;
		}
	});
	
	var veggiesCheckText = new Text(80, 130, 230, 60, "Veggies");
	
	// protein
	var protienCheckBox = new CheckBox(10, 200, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 1;
		}
	});
	
	var proteinCheckText = new Text(80, 200, 230, 60, "Protein");
	
	// dairy
	var dairyCheckBox = new CheckBox(10, 270, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 1;
		}
	});
	
	var dairyCheckText = new Text(80, 270, 230, 60, "Dairy");
	
	// whole grains
	var grainsCheckBox = new CheckBox(10, 340, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 1;
		}
	});
	
	var grainsCheckText = new Text(80, 340, 230, 60, "Grains");
	
	var eatReturnButton = new Button(10, 430, 300, 40, "Return", getImage("button.png"), function()
	{
		state = mainState;
		stateChange = true;
	});
	
	this.objects.push(checkTitle);
	
	this.objects.push(fruitCheckBox);
	this.objects.push(fruitCheckText);
	
	this.objects.push(veggiesCheckBox);
	this.objects.push(veggiesCheckText);
	
	this.objects.push(protienCheckBox);
	this.objects.push(proteinCheckText);
	
	this.objects.push(dairyCheckBox);
	this.objects.push(dairyCheckText);
	
	this.objects.push(grainsCheckBox);
	this.objects.push(grainsCheckText);
	
	this.objects.push(eatReturnButton);
});

var activitiesState = new State(function()
{
	// clear array of objects so we don't duplicate
	this.objects = [];
	
	var activitiesText = new Text(10, 10, 300, 40, "Activities");
	
	// walking
	var walkCheckBox = new CheckBox(10, 60, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var walkText = new Text(80, 60, 60, 60, "Walk");
	
	// biking
	var bikeCheckBox = new CheckBox(180, 60, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var bikeText = new Text(250, 60, 60, 60, "Bike");
	
	// running
	var runCheckBox = new CheckBox(10, 130, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var runText = new Text(80, 130, 60, 60, "Run");
	
	// swimming
	var swimCheckBox = new CheckBox(180, 130, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var swimText = new Text(250, 130, 60, 60, "Swim");
	
	// throwing
	var throwCheckBox = new CheckBox(10, 200, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var throwText = new Text(80, 200, 60, 60, "Throw");
	
	// jumping
	var jumpCheckBox = new CheckBox(180, 200, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var jumpText = new Text(250, 200, 60, 60, "Jump");
	
	// dancing
	var danceCheckBox = new CheckBox(10, 280, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var danceText = new Text(80, 280, 60, 60, "Dance");
	
	// kicking
	var kickCheckBox = new CheckBox(180, 280, 60, 60, getImage("checkedBox.png"), getImage("checkBox.png"), false, function(state)
	{
		if(state)
		{
			character.exp += 2;
		}
	});
	
	var kickText = new Text(250, 280, 60, 60, "Kick");
	
	// return button
	var activitiesReturnButton = new Button(10, 430, 300, 40, "Return", getImage("button.png"), function()
	{
		state = mainState;
		stateChange = true;
	});
	
	this.objects.push(activitiesText);
	
	this.objects.push(walkCheckBox);
	this.objects.push(walkText);
	
	this.objects.push(bikeCheckBox);
	this.objects.push(bikeText);
	
	this.objects.push(runCheckBox);
	this.objects.push(runText);
	
	this.objects.push(swimCheckBox);
	this.objects.push(swimText);
	
	this.objects.push(throwCheckBox);
	this.objects.push(throwText);
	
	this.objects.push(jumpCheckBox);
	this.objects.push(jumpText);
	
	this.objects.push(danceCheckBox);
	this.objects.push(danceText);
	
	this.objects.push(kickCheckBox);
	this.objects.push(kickText);
	
	this.objects.push(activitiesReturnButton);
});

var unlocksState = new State(function()
{
	// clear array of objects so we don't duplicate
	this.objects = [];
	
	var unlockablesText = new Text(10, 10, 300, 40, "Unlockables");
	
	var dudeButton = new Button(10, 60, 80, 80, "", getImage("dude.png"), function()
	{
		characterImageFile = "dude.png";
	});
	
	var blueKnightButton = new Button(100, 60, 80, 80, "", getImage("blueKnight.png"), function()
	{
		characterImageFile = "blueKnight.png";
	});
	
	var boy2Button = new Button(190, 60, 80, 80, "", getImage("boy2.png"), function()
	{
		characterImageFile = "boy2.png";
	});
	
	var boy3Button = new Button(10, 150, 80, 80, "", getImage("boy3.png"), function()
	{
		characterImageFile = "boy3.png";
	});
	
	var boy4Button = new Button(100, 150, 80, 80, "", getImage("boy4.png"), function()
	{
		characterImageFile = "boy4.png";
	});
	
	var boy5Button = new Button(190, 150, 80, 80, "", getImage("boy5.png"), function()
	{
		characterImageFile = "boy5.png";
	});
	
	var boy6Button = new Button(10, 240, 80, 80, "", getImage("boy6.png"), function()
	{
		characterImageFile = "boy5.png";
	});
	
	var boy7Button = new Button(100, 240, 80, 80, "", getImage("boy7.png"), function()
	{
		characterImageFile = "boy5.png";
	});
	
	var boy8Button = new Button(190, 240, 80, 80, "", getImage("boy8.png"), function()
	{
		characterImageFile = "boy5.png";
	});
	
	var unlocksReturnButton = new Button(10, 430, 300, 40, "Return", getImage("button.png"), function()
	{
		state = mainState;
		stateChange = true;
	});
	
	this.objects.push(unlockablesText);
	
	this.objects.push(dudeButton);
	
	if(character.level >= 5)
	{
		this.objects.push(blueKnightButton);
	}
	
	if(character.level >= 10)
	{
		this.objects.push(boy2Button);
	}
	
	if(character.level >= 15)
	{
		this.objects.push(boy3Button);
	}
	
	if(character.level >= 20)
	{
		this.objects.push(boy4Button);
	}
	
	if(character.level >= 25)
	{
		this.objects.push(boy5Button);
	}
	
	if(character.level >= 30)
	{
		this.objects.push(boy6Button);
	}
	
	if(character.level >= 35)
	{
		this.objects.push(boy7Button);
	}
	
	if(character.level >= 40)
	{
		this.objects.push(boy8Button);
	}
	
	this.objects.push(unlocksReturnButton);
});

function init()
{
	canvas = document.getElementById("cfgCanvas");
	context = canvas.getContext("2d");
    
   // canvas.width = window.innerWidth;
    //canvas.height = window.innerHeight;
	
	canvas.addEventListener("mousedown", notify);
	canvas.addEventListener("mouseup", notify);
	canvas.addEventListener("mousemove", notify);
	
	loadImage("dude.png");
	loadImage("button.png");
	loadImage("checkBox.png");
	loadImage("checkedBox.png");
	loadImage("backgroundDay.png");
	loadImage("backgroundNight.png");
	loadImage("border.png");
	loadImage("experience.png");
	
	loadImage("blueKnight.png");
	loadImage("boy2.png");
	loadImage("boy3.png");
	loadImage("boy4.png");
	loadImage("boy5.png");
	loadImage("boy6.png");
	loadImage("boy7.png");
	loadImage("boy8.png");
	
	loadSound("buttonPress.wav");
	
	state = mainState;
};

// main function
function main()
{
	var deltaTime = 1000 / 30;
	var running = true;
	
	var timer = setInterval(function()
	{
		if(running)
		{
			if(stateChange)
			{
				state.init();
				stateChange = false;
			}
			
			// update
			update(deltaTime);
	
			// draw
			draw();
		}
	}, deltaTime);
	
	if(!running)
	{
		clearInterval(timer);
	}
};

function notify(event)
{
	if(event)
	{
		var totalObjects = state.objects.length;
		for(var i = 0; i < totalObjects; i++)
		{
			if(typeof state.objects[i] !== "undefined" && typeof state.objects[i].notify === "function")
			{
				state.objects[i].notify(event, canvas);
			}
		}
	}
};

function update(dt)
{
	var totalObjects = state.objects.length;
	for(var i = 0; i < totalObjects; i++)
	{
		if(typeof state.objects[i].update === "function")
		{
			state.objects[i].update(dt);
		}
	}
	
	var hours = (new Date()).getHours();
	
	if(hours > 18 || hours < 6)
	{
		day = false;
	}
	else
	{
		day = true;
	}
	
	levelText.string = "level: " + character.level;
	
	expFillBar.level = character.exp / character.expToLevel;
	
	characterLevel = character.level;
	characterExp = character.exp;
};

function draw()
{
	context.clearRect(0, 0, canvas.width, canvas.height);
	
	if(day)
	{	
		context.drawImage(getImage("backgroundDay.png"), 0, 0, canvas.width, canvas.height);
	}
	else
	{
		context.drawImage(getImage("backgroundNight.png"), 0, 0, canvas.width, canvas.height);
	}
	
	var totalObjects = state.objects.length;
	for(var i = 0; i < totalObjects; i++)
	{
		if(typeof state.objects[i].draw === "function")
		{
			state.objects[i].draw(context);
		}
	}
};

window.onload = function()
{
	init();
	
	main();
};

window.onbeforeunload = function()
{
	localStorage.setItem("exp", String(characterExp));
	localStorage.setItem("level", String(characterLevel));
};
