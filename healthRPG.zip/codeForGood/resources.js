// resource loader
var images = [];
var sounds = [];

function loadImage(file)
{
	images[file] = new Image();
	images[file].src = file;
	
	images[file].onerror = function()
	{
		alert("Couldn't load: " + file + " as an image");
	};
};

function getImage(file)
{
	if(typeof images[file] === "undefined")
	{
		alert("Image: " + file + " undefined");
	}
	else
	{
		return images[file];
	}
};

function loadSound(file)
{
	sounds[file] = new Audio();
	sounds[file].src = file;
	
	sounds[file].onerror = function()
	{
		alert("Couldn't load: " + file + " as a sound");
	};
};

function getSound(file)
{
	if(typeof sounds[file] === "undefined")
	{
		alert("Sound: " + file + " undefined");
	}
	else
	{
		return sounds[file];
	}
};
