// position, size, checked image, unchecked image, true or false state, callback function
function CheckBox(x, y, w, h, imgOn, imgOff, state, func)
{
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	
	this.imageOn = imgOn;
	this.imageOff = imgOff;
	
	this.state = state;
	
	this.image = (this.state ? this.imageOn : this.imageOff);
	
	this.callback = func;
	
	this.lighten = false;
	
	this.notify = function(event)
	{
		if(event && canvas)
		{
			var x = event.pageX - canvas.offsetLeft;
			var y = event.pageY - canvas.offsetTop;
			
			// check for click inside of button
			if((x > this.x && x < this.x + this.w) && (y > this.y && y < this.y + this.h))
			{	
				if(event.type == "mousedown")
				{
					this.state = !this.state;
					this.image = (this.state ? this.imageOn : this.imageOff);
					getSound("buttonPress.wav").play();
					this.callback(this.state);
				}
				else if(event.type == "mousemove")
				{
					this.lighten = true;
				}
			}
			else
			{
				this.lighten = false;
			}
		}
	};
	
	this.draw = function(context)
	{
		context.drawImage(this.image, this.x, this.y, this.w, this.h);
	};
};
