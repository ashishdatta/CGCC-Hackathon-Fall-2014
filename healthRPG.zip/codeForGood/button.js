// position, size, text to display on button, image, callback function
function Button(x, y, w, h, text, img, func)
{
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	
	this.text = text;
	
	this.image = img;
	
	this.callback = func;
	
	this.lighten = false;
	
	this.notify = function(event, canvas)
	{
		if(event && canvas)
		{
			var x = event.pageX - canvas.offsetLeft;
			var y = event.pageY - canvas.offsetTop;
			
			// check for click inside of button
			if((x > this.x && x < this.x + this.w) && (y > this.y && y < this.y + this.h))
			{
				if(event.type == "mousedown")
				{
					getSound("buttonPress.wav").play();
					this.callback();
				}
				else if(event.type == "mousemove")
				{
					this.lighten = true;
				}
			}
			else
			{
				this.lighten = false;
			}
		}
	};
	
	this.draw = function(context)
	{
		context.drawImage(this.image, this.x, this.y, this.w, this.h);
		context.font = "20pt Calibri";
		context.textBaseline = "middle";
		context.textAlign = "center";
		context.fillStyle = "#000000";
		context.fillText(this.text, this.x + this.w / 2, this.y + this.h / 2);
	};
};
