// position, size, name, phrase to say, image
function Character(x, y, w, h, name, phrase, img)
{
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	
	this.name = name;
	this.phrase = phrase;
	
	this.image = img;
	
	this.level = 1;
	this.exp = 0;
	this.expToLevel = 20;
	
	this.say = function()
	{
		alert("Hello!! My name is " + this.name + " and " + this.phrase);
	};
	
	this.notify = function(event, canvas)
	{
		if(event)
		{
			
		}
	};
	
	this.update = function(dt)
	{	
		if(this.exp >= this.expToLevel)
		{
			this.level++;
			this.exp -= this.expToLevel;
			this.expToLevel *= 1.25;
		}
	};
	
	this.draw = function(context)
	{
		context.drawImage(this.image, x, y, w, h);
	};
};
